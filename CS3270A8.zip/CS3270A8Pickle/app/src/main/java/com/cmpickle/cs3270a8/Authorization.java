package com.cmpickle.cs3270a8;

/**
 * @author Cameron Pickle
 *         Copyright (C) Cameron Pickle (cmpickle) on 3/1/2017.
 */

public class Authorization {

    protected static String AUTH_TOKEN = "";
}
